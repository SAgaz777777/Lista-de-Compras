
export { default } from '../App';