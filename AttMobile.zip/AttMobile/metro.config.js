const path = require('path');
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);
const reactPackagePath = path.dirname(require.resolve('react'));

config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (moduleName === 'react' || moduleName.startsWith('react/')) {
    const canonicalModulePath = path.join(
      reactPackagePath,
      moduleName.slice('react'.length)
    );
    return context.resolveRequest(context, canonicalModulePath, platform);
  }

  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
